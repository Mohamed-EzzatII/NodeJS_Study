Create 3 files (student, courses, department) 
1- Student contains: 
• Id 
• Name 
• Email 
• Password 
• DepartmentId 
2- Course contains: 
• Id 
• Name 
• Content 
• DepartmentId 
3- department contains: 
• Id 
• Name 

Student APIs 
1- Add student(email must be unique) 
2- GetAll students 
3- Get all students with their department and courses related to the department 
4- delete student 
5- update student 
6- search for a student by ID 

Courses APIs 
1- Add courses  
2- Delete Course 
3- Update course 
4- Get all courses

Department APIs  
1- Add department 
2- Update department 
3- Delete department 
4- Get all departments  
5- Get specific department by Id 